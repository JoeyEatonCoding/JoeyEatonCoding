package operations;

/* Name: Joey Eaton
 * Class: Computer Programming 1
 * Program: Takes 2 input integers and results with sum, difference, product, average, |difference|, maximum, and minimum
 * Date: 2/9/2025
 * 
 */

import java.util.Scanner;

public class MathOperations {
	
	public static void main(String[] args) {
		//Section which reads user input
		Scanner scanner  = new Scanner(System.in);
		
		System.out.print("Enter the first integer: ");
		int num1 = scanner.nextInt();
		
		System.out.print("Enter the second integer: ");
		int num2 = scanner.nextInt();
		
		//Performs Calculations of Numbers
		int sum = num1 + num2;
		int difference = num1 - num2;
		int product = num1 * num2;	
		int	average = (sum) /2;
		int	absolteDifference = Math.abs(difference);	
		int	max	= Math.max(num1,  num2);
		int	min	= Math.min(num1,  num2);
		
		System.out.println("The Sum is: " + sum); 
		System.out.println("The Difference is: " + difference); 
		System.out.println("The Product is: " + product); 
		System.out.println("The Average is: " + average); 
		System.out.println("The Absolute Difference is: " + absolteDifference); 
		System.out.println("The Maximum is: " + max); 
		System.out.println("The Minimum is: " + min); 
		
		scanner.close();
	}

}
