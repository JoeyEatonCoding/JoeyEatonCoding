/* Joey Eaton
 * This Program Classifies Tornadoes by Speed
 * Class: Computer Programming 1
 * 2/14/2025
 */

package classifierJE;

import java.util.Scanner;

public class Type {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Enter Tornado Speed (MPH): ");
        int speed = scanner.nextInt();
		
        if (speed < 40)
        {
        	System.out.print("Not a tornado!");
        }
        else if (speed < 73)
        {
        	System.out.print("F-0");
        }
        else if (speed < 113)
        {
        	System.out.print("F-1");
        }
        else if (speed < 158)
        {
        	System.out.print("F-2");
        }
        else if (speed < 206)
        {
        	System.out.print("F-3");
        }
        else if (speed < 261)
        {
        	System.out.print("F-4");
        }
        else
        {
        	System.out.print("F-5");
        }
        scanner.close();
	}
}
