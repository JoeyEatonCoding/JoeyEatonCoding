/**
 * 
 */
/**
 * 
 */
module ComputeAreaJE {
}