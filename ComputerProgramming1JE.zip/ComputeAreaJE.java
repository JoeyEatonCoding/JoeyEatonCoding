/*Compute Area
 * Joey Eaton
 * Description: This program calculates the area of a rectangle
 * Course: Computer Programming 1 (Professor Chundur)

 */


package CP1;

public class ComputeAreaJE {

	public static void main(String[] args) {
		// Define the length and width
        int length = 10;
        int width = 8;

        // Calculate the area
        int area = length * width;
        System.out.print(area);
	}

}
